import { defineConfig } from "vitest/config";
import react from "@vitejs/plugin-react";

export default defineConfig({
  plugins: [react()],
  test: {
    globals: true,
    setupFiles: ["./src/__tests__/setup.ts"],
    include: [
      "src/**/*.test.{ts,tsx}",
      "server/**/*.test.mjs",
    ],
    // Frontend component/DOM tests need jsdom; the plain-Node server modules
    // (server/**) run faster and more accurately under the real "node"
    // environment (they touch fs, crypto, sockets — no DOM involved).
    environmentMatchGlobs: [
      ["server/**", "node"],
      ["src/**", "jsdom"],
    ],
  },
});
